import { useState } from 'react';
import './App.css';
import DisplayBoard from './conponets/DisplayBoard.jsx';
import TaskForm from './conponets/TaskForm.jsx';

const intialTasks = [
  {
    id: 1,
    name: 'Go to school',
    description: 'Off to school',
    date: '2025-02-25',
    time: '07:03',
  },
  {
    id: 2,
    name: 'Go to meeting',
    description: 'Off to the kingdom hall',
    date: '2020-03-20',
    time: '04:00',
  },
  {
    id: 3,
    name: 'Read your book',
    description: 'You need to feed your brain',
    date: '2015-01-05',
    time: '05:00',
  },
];

function App() {
  const [editTask, setEditTask] = useState(null);
  const [tasks, setTasks] = useState(intialTasks);

  // const [updateTask, setUpdateTask] = useState([]);

  function handelDeleteTask(id) {
    confirm('Do you want to delete this task?') &&
      setTasks((oldTasks) => oldTasks.filter((task) => task.id !== id));
  }

  // Edit task function
  function handelEditBtn(task) {
    // editTask === id ? setEditTask(0) : setEditTask(id);
    !editTask
      ? setEditTask((cur) => (cur?.id === task.id ? null : task))
      : setEditTask(null);
  }

  return (
    <div className="todo">
      <div className="taskInputBoard">
        <TaskForm
          // handTasksUpdate={tasks}
          editTask={editTask}
          handelEditTask={setEditTask}
          handelTask={setTasks}
        />
        {/* ) : (
          <TaskForm formBtn="Update" />
        )} */}
      </div>

      {!tasks.length ? (
        <div className="taskDisplayBoard">
          <h2 className="title">You have no task avaliable</h2>{' '}
        </div>
      ) : (
        <DisplayBoard
          handelEditBtn={handelEditBtn}
          tasks={tasks}
          onDeleteTask={handelDeleteTask}
        />
      )}
      {/* <div className="editBoard">
        <TaskForm formBtn="Update" />
      </div> */}
    </div>
  );
}

export default App;

// This App was Completed on Sunday March 9th 2025 by 5:49pm
// This is my very first React App. I'm so grateful to Uncle Dozie for all his advice and encouragements. My greatest Thanks goes to Jehovah for giving the strenght even when i'm weak...

// This is a new Dawn
