import '../assets/styles/service.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { library } from '@fortawesome/fontawesome-svg-core';
import { fas } from '@fortawesome/free-solid-svg-icons';

library.add(fas);

export default function Services({ title, info, icon, iconBg }) {
  return (
    <li>
      <span className="service-detail">
        <span style={{ backgroundColor: iconBg }} className="service-icon">
          <FontAwesomeIcon icon={icon} />
        </span>
        <span className="service-title">
          <h4>{title}</h4>
          <p>{info}</p>
        </span>
      </span>

      <span className="service-arrow">
        <FontAwesomeIcon icon={faChevronRight} />
      </span>
    </li>
  );
}
