export const services = [
  {
    title: 'account service',
    info: 'update your account',
    icon: ' fa-solid fa-arrows-turn-right',
    iconbg: 'green',
  },
  {
    title: 'card pin service',
    info: 'update your pin',
    icon: 'fa-solid fa-book',
    iconbg: 'orange',
  },
  {
    title: 'check book service',
    info: 'update your check book',
    icon: 'fa-solid fa-book',
    iconbg: 'skyblue',
  },
  {
    title: 'check status',
    info: 'view your check book status',
    icon: 'fa-solid fa-book',
    iconbg: 'blue',
  },
  {
    title: 'personal details',
    info: 'view your details',
    icon: 'fa-solid fa-arrows-turn-right',
    iconbg: 'green',
  },
  {
    title: 'contact us',
    info: 'reach out to us',
    icon: 'fa-solid fa-headset',
    iconbg: 'red',
  },
  {
    title: 'about us',
    info: 'learn more about us',
    icon: 'fa-solid fa-arrows-turn-right',
    iconbg: 'rgb(72, 31, 92)',
  },
];
