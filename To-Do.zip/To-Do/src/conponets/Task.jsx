import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faTrash,
  faPen,
  faCalendarAlt,
  faClock,
} from '@fortawesome/free-solid-svg-icons';

export default function Task({
  name,
  description,
  date,
  time,
  onDeleteTask,
  id,
  handelEditBtn,
  task,
}) {
  return (
    <li>
      <div>
        <span
          onClick={() => handelEditBtn(task)}
          className="taskEdit"
          title="Edit"
        >
          <FontAwesomeIcon icon={faPen} />
        </span>
        <span className="taskInfo">
          <h4 className="taskName">{name}</h4>
          <p className="taskDescription">{description}</p>
          <p className="taskDate">
            <FontAwesomeIcon icon={faCalendarAlt} /> {date} at{' '}
            <FontAwesomeIcon icon={faClock} /> {time}
          </p>
        </span>
        <span
          onClick={() => onDeleteTask(id)}
          className="taskDelete"
          title="Delete"
        >
          <FontAwesomeIcon icon={faTrash} />
        </span>
      </div>
    </li>
  );
}
