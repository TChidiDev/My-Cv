export default function Button({ cssClass, name, handelClick }) {
  return (
    <button onClick={handelClick} className={cssClass}>
      {name}
    </button>
  );
}
