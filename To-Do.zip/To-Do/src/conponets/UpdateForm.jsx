import { useState } from 'react';
import Button from './Button.jsx';

export default function UpdateForm({ task, handelCancelBtn, handTasksUpdate }) {
  const [name, setName] = useState(task.name);
  const [description, setDescription] = useState(task.description);
  const [time, setTime] = useState(task.time);
  const [date, setDate] = useState(task.date);
  // Editing Task Function
  console.log(task);

  function handelSubmitEdit(e) {
    e.preventDefault();
    console.log('edit');
  }

  function handelEditSubmitEdit(e) {
    e.preventDefault();

    if (!name || !date || !description || !time) return;

    handTasksUpdate((i) =>
      i.map((t) =>
        t.id === task.id ? { ...t, name, description, time, date } : t
      )
    );

    handelCancelBtn(null);
  }

  // Cancel/Close Edit Task Box
  //   function closeEdit() {
  //     handelEditTask((i) => !i);
  //   }
  //   const edit = {};

  //   setEditTask((edit) =>
  //     edit.filter(
  //       (task) => task.id === taskNum && console.log(taskNum)

  //       // {
  //       //     ...edit,
  //       //     name: task.name,
  //       //     description: task.description,
  //       //     date: task.date,
  //       //     time: task.time,
  //       //   }
  //     )
  //   );

  return (
    <form onSubmit={handelEditSubmitEdit}>
      <div className="taskInput">
        <input
          type="text"
          placeholder="Task name here..."
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>
      <div className="taskAction">
        <div className="taskActionDate">
          <label htmlFor="date">Date:</label>
          <input
            type="date"
            name=""
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
          <label htmlFor="time">Time:</label>
          <input
            type="time"
            name=""
            id="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
          />
        </div>
        <div className="taskActionBtn">
          <Button
            cssClass="cancelBtn"
            name="Cancel"
            handelClick={() => handelCancelBtn(null)}
          />
          <Button cssClass="addBtn" name="Update" />
        </div>
      </div>
    </form>
  );
}
