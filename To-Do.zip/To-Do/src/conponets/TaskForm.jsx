import { useState } from 'react';
import Button from './Button.jsx';
import UpdateForm from './UpdateForm.jsx';

export default function TaskForm({ handelTask, editTask, handelEditTask }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  const id = crypto.randomUUID();

  function handelTaskClear(e) {
    e.preventDefault();
    setDate('');
    setDescription('');
    setName('');
    setTime('');
  }

  function handelSubmit(e) {
    e.preventDefault();

    if (!name || !date || !description || !time) return;
    console.log('trust');

    const newTask = {
      id,
      name,
      description,
      date,
      time,
    };

    handelTask((oldTask) => [...oldTask, newTask]);
    setDate('');
    setDescription('');
    setName('');
    setTime('');
  }

  return !editTask ? (
    <form onSubmit={handelSubmit}>
      <div className="taskInput">
        <input
          type="text"
          placeholder="Task name here..."
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>
      <div className="taskAction">
        <div className="taskActionDate">
          <label htmlFor="date">Date:</label>
          <input
            type="date"
            name=""
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
          <label htmlFor="time">Time:</label>
          <input
            type="time"
            name=""
            id="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
          />
        </div>
        <div className="taskActionBtn">
          <Button
            cssClass="cancelBtn"
            name="Cancel"
            handelClick={handelTaskClear}
          />
          <Button
            cssClass="addBtn"
            handelClick={handelSubmit}
            name="Add Task"
          />
        </div>
      </div>
    </form>
  ) : (
    <UpdateForm
      handelCancelBtn={handelEditTask}
      task={editTask}
      handTasksUpdate={handelTask}
    />
  );
}
