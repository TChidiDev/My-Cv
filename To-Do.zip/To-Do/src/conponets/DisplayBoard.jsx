import Task from './Task';

export default function DisplayBoard({ tasks, onDeleteTask, handelEditBtn }) {
  const taskNumber = tasks.length;
  return (
    <div className="taskDisplayBoard">
      <h2 className="title">
        Tasks Todo <span className="taskAmount">{taskNumber}</span>
      </h2>
      <ul className="todoList">
        {tasks.map((task) => (
          <Task
            key={task.id}
            name={task.name}
            description={task.description}
            date={task.date}
            time={task.time}
            onDeleteTask={onDeleteTask}
            id={task.id}
            handelEditBtn={handelEditBtn}
            task={task}
          />
        ))}
      </ul>
    </div>
  );
}
